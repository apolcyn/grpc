using Google.Cloud.Datastore.V1;
using Grpc.Core;
using Math;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using static Google.Cloud.Datastore.V1.Datastore;
using static Math.Math;

class Program
{
    const int Port = 23456;
    const int MaxRequestsInFlight = 100;

    static void Main(string[] args)
    {
        if (args.Length != 1)
        {
            Console.WriteLine("Argument: server|mathclient|datastoreclient");
            return;
        }
        switch (args[0])
        {
            case "server":
                RunServer();
                break;
            case "mathclient":
                RunMathClient();
                break;
            case "datastoreclient":
                RunDatastoreClient();
                break;
        }        
    }

    static void RunMathClient()
    {
        var credentials = ChannelCredentials.Insecure;
        var channel = new Channel("localhost", Port, credentials);
        var client = new MathClient(channel);
        var request = new DivArgs { Dividend = 4, Divisor = 2 };

        RunClient(() => client.DivAsync(request).ResponseAsync);
    }

    static void RunDatastoreClient()
    {
        var credentials = ChannelCredentials.Insecure;
        var channel = new Channel("localhost", Port, credentials);
        var client = new Datastore.DatastoreClient(channel);
        var request = new BeginTransactionRequest { };// ProjectId = "Foo" };

        RunClient(() => client.BeginTransactionAsync(request).ResponseAsync);
    }

    static void RunClient(Func<Task> requester)
    {
        long sent = 0;
        long complete = 0;
        long errors = 0;

        new Thread(() =>
        {
            Process process = Process.GetCurrentProcess();
            while (true)
            {
                Thread.Sleep(10000);
                var s = Interlocked.Read(ref sent);
                var c = Interlocked.Read(ref complete);
                var e = Interlocked.Read(ref errors);
                Console.WriteLine($"{DateTime.UtcNow:HH:mm:ss} Sent: {s,7}; Complete: {c,7}; Errors: {e,7}; Private bytes: {process.PrivateMemorySize64,10}");
                process.Refresh();
            }
        }).Start();

        var semaphore = new Semaphore(MaxRequestsInFlight, MaxRequestsInFlight);
        while (true)
        {
            var task = requester();
            sent++;
            semaphore.WaitOne();
            task.ContinueWith(t =>
            {
                var c = Interlocked.Increment(ref complete);
                if (t.IsFaulted)
                {
                    Interlocked.Increment(ref errors);
                }
                semaphore.Release();
            }, TaskScheduler.Default);
        }
    }

    static void RunServer()
    {
        var credentials = ServerCredentials.Insecure;
        Server server = new Server
        {
            Services = {
                Math.Math.BindService(new MathServiceImpl()),
                Datastore.BindService(new DatastoreServerImpl())
            },
            Ports = { { "0.0.0.0", Port, credentials } }
        };
        server.Start();
        Console.WriteLine("Running. Hit return to stop");
        Console.ReadLine();
    }

    class MathServiceImpl : MathBase
    {
        private static readonly Task<DivReply> reply = Task.FromResult(new DivReply { Quotient = 2, Remainder = 0 });

        public override Task<DivReply> Div(DivArgs request, ServerCallContext context) => reply;
    }

    class DatastoreServerImpl : DatastoreBase
    {
        private static readonly Task<BeginTransactionResponse> beginTransactionResponse = Task.FromResult(new BeginTransactionResponse());

        public override Task<BeginTransactionResponse> BeginTransaction(BeginTransactionRequest request, ServerCallContext context) => beginTransactionResponse;
    }
}
